<!-- git -->
<!-- => 파일 관리, 기록 시스템 -->

<!-- github -->
<!-- => git 관리된 파일을 업로드 하여 -->
<!-- 저장 및 공유 -->

<!-- git.add
git commit -m "header modify"
git push origin master -->

<!-- *git 명령어
0. 유저등록(처음만 실행)
=> git config --global user.name "긱허브 아이디"
=> git config --global user.email "긱허브 메일주소"

1. git init.

2. 스테이지
git add .

3. 기록
git commit -m "메세지 내용 입력"

4. 저장소 생성
=> 깃허브에 가서 저장소 생성
=> 저장소 명, 내용(옵션사항), public(공용)

5. 저장소 url주소 복사
=> vscode 터미널에서 git remote add origin 저장소 주소

6. 저장소 업로드
=> git push origin master(또는 main)
-->
