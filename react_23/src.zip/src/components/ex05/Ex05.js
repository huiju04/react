import { CssEx } from "./componets/CssEx";
import { StyledEx } from "./componets/StyledEx";

export const Ex05 = () => {
  return (
    <div>
      {/* <CssEx /> */}
      <StyledEx />
    </div>
  );
};
