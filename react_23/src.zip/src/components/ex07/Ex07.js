import { EventEx } from "./components/EventEx";
import { EventEx02 } from "./components/EventEx02";

export const Ex07 = () => {
  return (
    <div>
      {/* <EventEx /> */}
      <EventEx02 />
    </div>
  );
};
