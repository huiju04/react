import { MusicApp } from "./compornents/MusicApp";

export const Ex09 = () => {
  return (
    <div>
      <MusicApp />
    </div>
  );
};
