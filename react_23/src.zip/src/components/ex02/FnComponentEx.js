const FnComponentEx = () => {
  return <div>컴포넌트!</div>;
};

export default FnComponentEx;
