import { MuiscApp } from "./compornents/MusicApp";

export const Ex10 = () => {
  return (
    <div>
      <MuiscApp />
    </div>
  );
};
